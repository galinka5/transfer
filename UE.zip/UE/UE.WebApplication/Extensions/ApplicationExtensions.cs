﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using UE.Db.Main;
using UE.Db.Seed;

namespace UE.WebApplication.Extensions
{
    public static class ApplicationExtensions
    {
        public static void UpdateDatabase(this IApplicationBuilder app, ApplicationSeeder seeder)
        {
            using (var serviceScope = app.ApplicationServices
                .GetRequiredService<IServiceScopeFactory>()
                .CreateScope())
            {
                using (var context = serviceScope.ServiceProvider.GetService<UEDbContext>())
                {
                    context.Database.Migrate();
                }
            }

            seeder.SeedData().GetAwaiter().GetResult();
        }
    }
}
