﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using UE.Db.Main;
using UE.Models.Authentication;
using UE.WebApplication.Installers;

namespace UE.WebApplication.Extensions
{
    public static class ServicesExtensions
    {
        public static void InstallServices(this IServiceCollection services, IConfiguration configuration)
        {
            var installers = typeof(Startup).Assembly.ExportedTypes
                .Where(x => typeof(IInstaller).IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract).Select(Activator.CreateInstance).Cast<IInstaller>().ToList();
            installers.ForEach(installer => installer.InstallServices(services, configuration));
        }

        public static void InstallAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddIdentityCore<ApplicationUser>(options =>
            {
                options.Password.RequiredLength = 6;
                options.Password.RequireUppercase = true;
                options.Password.RequireDigit = true;
                options.Password.RequireNonAlphanumeric = false;
                options.SignIn.RequireConfirmedEmail = true;
                options.User.RequireUniqueEmail = true;
            })
           .AddRoles<ApplicationRole>()
           .AddUserStore<UserStore<ApplicationUser,
                                   ApplicationRole,
                                   UEDbContext,
                                   string,
                                   IdentityUserClaim<string>,
                                   ApplicationUserRole,
                                   IdentityUserLogin<string>,
                                   IdentityUserToken<string>,
                                   IdentityRoleClaim<string>>>()
           .AddRoleStore<RoleStore<ApplicationRole,
                                   UEDbContext,
                                   string,
                                   ApplicationUserRole,
                                   IdentityRoleClaim<string>>>()
           .AddDefaultTokenProviders();

            services.AddDbContext<UEDbContext>(options =>
                options.UseSqlServer(configuration["ApplicationSettings:ConnectionString"]));
        }
    }
}
