﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UE.WebApplication.Extensions
{
    public static class Routes
    {

    }
}
