﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Threading.Tasks;
using UE.Domain.Common;
using UE.WebApplication.Helpers;

namespace UE.WebApplication.Extensions
{
    /// <summary>
    ///     Exception Middleware register extension.
    /// </summary>
    public static class ErrorLoggingMiddlewareExtensions
    {
        /// <summary>
        ///     Register Exception Middleware.
        /// </summary>
        /// <param name="builder"> Application builder </param>
        /// <returns> Application builder </returns>
        public static IApplicationBuilder UseErrorLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ExceptionMiddleware>();
        }
    }

    /// <summary>
    ///     Handle unhandled application exceptions.
    /// </summary>
    public class ExceptionMiddleware
    {
        private readonly ILogger _logger;
        private readonly RequestDelegate _next;

        /// <summary>
        ///     Initialize new instance of <see cref="ExceptionMiddleware" />.
        /// </summary>
        /// <param name="next"> Next request handler </param>
        /// <param name="logger"> Application logger </param>
        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
        {
            _logger = logger;
            _next = next;
        }

        /// <summary>
        ///     Invoke middleware.
        /// </summary>
        /// <param name="httpContext"> HttpContext </param>
        /// <returns> Async task </returns>
        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Application exception: {ex.Message}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        /// <summary>
        ///     Make user response with custom message.
        /// </summary>
        /// <param name="context"> HttpContext </param>
        /// <param name="exception"> Unhandled exception </param>
        /// <returns> Async task </returns>
        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            return context.Response.WriteAsync(new ErrorDetails
            {
                Id = context.TraceIdentifier,
                StatusCode = context.Response.StatusCode,
                Message = exception.Message,
                InnerException = exception.InnerException?.Message ?? "NONE"
            }.ToJson());
        }
    }
}
