﻿using Microsoft.Extensions.Configuration;

namespace UE.WebApplication.Extensions
{
    public static class ConfigurationExtensions
    {
        /// <summary>
        ///     Compose all configuration files together.
        /// </summary>
        /// <param name="builder"> App Configuration Builder </param>
        /// <param name="envName"> Environment name </param>
        /// <returns> Configuration Builder </returns>
        public static IConfigurationBuilder ComposeConfigFiles(this IConfigurationBuilder builder, string envName)
        {
            return builder
                .AddJsonFile("appsettings.json", false, true)
                .AddJsonFile($"appsettings.{envName}.json", false, true)
                .AddEnvironmentVariables();
        }
    }
}
