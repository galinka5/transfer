﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NQ.Services.Hubspot;
using UE.Common.Settings;
using UE.Db.Seed;
using UE.Domain.Authentication;
using UE.Domain.Users;
using UE.Models.Authentication;

namespace UE.WebApplication.Installers
{
    public class DIInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<HubspotSettings>(configuration.GetSection(nameof(HubspotSettings)));
            services.AddHttpContextAccessor();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddTransient<ApplicationSeeder>();
            services.AddScoped<IUrlHelper>(factory =>
            {
                var actionContext = factory.GetService<IActionContextAccessor>().ActionContext;
                if (actionContext != null)
                    return new UrlHelper(actionContext);
                else
                    return null;
            });
            services.AddScoped<IUserClaimsPrincipalFactory<ApplicationUser>, ClaimsPrincipalFactory>();

            services.AddScoped<IAuthenticationContext, AuthenticationContext>();

            services.AddScoped<IUsersManager, UsersManager>();

            services.AddScoped<IHubspotServices, HubspotServices>();
        }
    }
}
