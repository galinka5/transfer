﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using UE.Domain.Products.Dto;


namespace UE.WebApplication.Controllers
{
    public class ProductsController : Controller
    {

        public IActionResult AddProduct(bool earlyregistration = true)
        {
            ViewBag.EarlyRegistration = earlyregistration;
            return View();
        }

        [HttpPost]
        public ActionResult UploadImage(IFormFile file)
        {
            if (file != null)
            {
                // do something
                return Json(new { result = 1 });
            }

            return Json(new { result = 0 });
        }

        [HttpPost]
        public ActionResult Preview(String Title, String Description)
        {
            return View("AddProduct");
            //return Json(new { result = 0, title=Title, desc=Description });
        }

        public ActionResult Publish(ProductInfo info)
        {
            return View("AddProduct");
            //return Json(new { info });
        }
    }
}
