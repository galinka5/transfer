﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UE.Common.Enums;
using UE.Domain.Users;
using UE.Domain.Users.Dto;

namespace UE.WebApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUsersManager usersManager;

        public AccountController(IUsersManager _usersManager)
        {
            usersManager = _usersManager;
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult SignupSelect()
        {
            return View();
        }

        public IActionResult RegisterPromoter()
        {
            var model = new RegisterUserModel();
            model.RegistrationType = RegistrationTypes.Influencer;
            return View("~/Views/Account/Register.cshtml", model);
        }

        public IActionResult RegisterOwner()
        {
            var model = new RegisterUserModel();
            model.RegistrationType = RegistrationTypes.ProductOwner;
            return View("~/Views/Account/Register.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> RegisterEmail(RegisterUserModel model)
        {
            var result = await usersManager.RegisterEmail(model);
            return Json(new { isSuccess = true, userId = result });
        }

        [HttpPost]
        public async Task<IActionResult> RegisterDetails(RegisterUserModel model)
        {
            await usersManager.RegisterDetails(model);
            return RedirectToAction("RegisterSuccess");
        }

        public IActionResult RegisterSuccess()
        {
            return View();
        }

        public IActionResult Subscribe(string email)
        {
            usersManager.RegisterSubscriber(email);
            return RedirectToAction("RegisterSuccess");
        }
    }
}