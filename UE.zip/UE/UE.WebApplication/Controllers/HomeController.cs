﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using UE.WebApplication.Models;
using UE.WebApplication.Models.Common;
using System.Collections.Generic;
using System.Linq;


namespace UE.WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        internal void AddBreadcrumb(string name, string route, bool active = false)
        {
            if (ViewBag.Breadcrumbs == null)
            {
                ViewBag.Breadcrumbs = new List<BreadcrumbModel>();
            }
            ViewBag.Breadcrumbs.Add(new BreadcrumbModel(name, route, active));
        }

        private void SetupBreadcrumbs(string name, string route)
        {
            AddBreadcrumb("Home", "home");
            AddBreadcrumb(name, route, true);
        }

        public IActionResult Index()
        {
            ViewBag.EarlyRegistration = true;
            return View();
        }
       
        public IActionResult Full()
        {
            ViewBag.EarlyRegistration = false;
            return View("~/Views/Home/Index.cshtml");
        }

        [HttpGet("~/privacy")]
        public IActionResult Privacy()
        {
            ViewBag.EarlyRegistration = true;
            SetupBreadcrumbs("Privacy Policy", "");
            return View();
        }

        [HttpGet("~/disclaimers")]
        public IActionResult Disclaimers()
        {
            ViewBag.EarlyRegistration = true;
            SetupBreadcrumbs("Disclaimer", "");
            return View();
        }

        [HttpGet("~/terms")]
        public IActionResult Terms()
        {
            ViewBag.EarlyRegistration = true;
            SetupBreadcrumbs("Terms and Conditions", "");
            return View();
        }

        public IActionResult Comingsoon()
        {
            return View();
        }

        public IActionResult Vision()
        {
            return View();
        }

        [HttpGet("~/product-owners")]
        public IActionResult ArticleOwners(bool earlyregistration = true)
        {
            ViewBag.EarlyRegistration = earlyregistration;
            return View();
        }

        [HttpGet("~/promoters")]
        public IActionResult ArticlePromoter(bool earlyregistration = true)
        {
            ViewBag.EarlyRegistration = earlyregistration;
            return View();
        }

        public IActionResult ProductOwners()
        {
            return View();
        }

        [HttpGet("~/webinar")]
        public IActionResult webinar()
        {
            return View();
        }

        public IActionResult Promoters()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
