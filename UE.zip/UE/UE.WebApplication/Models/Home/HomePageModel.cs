﻿using System.Collections.Generic;
using UE.Domain.EquityOpportunities.Dto;

namespace UE.WebApplication.Models.Home
{
    public class HomePageModel
    {
        public List<UserFeedback> UserFeedbacks { get; set; }

        public List<Opportunity> Opportunities { get; set; }
    }
}
