﻿namespace UE.WebApplication.Models.Home
{
    public class UserFeedback
    {
        public string Quote { get; set; }

        public string Author { get; set; }

        public string Company { get; set; }

        public string ImageUrl { get; set; }
    }
}
