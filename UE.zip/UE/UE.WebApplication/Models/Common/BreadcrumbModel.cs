﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UE.WebApplication.Models.Common
{
    public class BreadcrumbModel
    {
        public string Name { get; set; }

        public string Route { get; set; }

        public bool Active { get; set; }

        public BreadcrumbModel(string name, string route, bool active = false)
        {
            Name = name;
            Route = route;
            Active = active;
        }
    }
}
