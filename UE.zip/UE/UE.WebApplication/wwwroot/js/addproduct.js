﻿$(document).ready(function () {
    // prevent form post on ENTER
    $('#addProductForm').on('keyup keypress', function (e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });
    // create all dropdowm seletrics
    $('select').selectric();

    // for drag-and-drop sections
    $("#sectionSortable").sortable({
        connectWith: ".connected-sortable",
        handle: ".draggable-block-header"
    });

    $("#imageUploader").change(function () {
        filePreview(this);
    });

    $('#deleteImgBtn').on('click', function () {
        $('#imageUploader').val('');
        $('#imageUploadForm .preview').css('background-image', 'none');
    });

    $('#publishBtn').on('click', function () {});

    $('.tag-item').on('click', '.cross', function () {
        $(this).parent().remove();
    });

    $('#inputTags').keyup(function (e) {
        e.stopImmediatePropagation();
        if (e.keyCode == 13) {
            addTag($('#inputTags').val());
            $('#inputTags').val('');
        }
    });

    $('.draggable-block').on('click', '.cross', function () {
        $(this).closest('.draggable-block').remove();
    });

    $('.addnew-block-btn').on('click', function () {
        addNewBlock($(this));
    });

    $('.toggle-btn').on('click', function () {
        var btn = $(this);
        btn.toggleClass('checked');
        if (btn.hasClass('checked')) 
             btn.parent().next().find('input').removeAttr('disabled')
        else btn.parent().next().find('input').attr('disabled', true)
    });


    $('.datepicker').datepicker(/*
        {
            changeMonth: true,
            changeYear: true,
            minDate: "-5Y",
            maxDate: "+10Y"
        }*/);

    updateIDs();
    initRichtextEditor('#dr-block-1');
    initPlUploader('#dr-block-2');
});

function filePreview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imageUploadForm + img').remove();
            $('#imageUploadForm .preview').css('background-image', 'url(' + e.target.result + ')');
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function updateIDs() {
    console.log($('#sectionSortable .draggable-block').length);
    var i = 1;
    $('#sectionSortable .draggable-block').each(function () {
        $(this).find('.collapse-btn')
               .attr('href', '#dr-block-' + i)
               .attr('aria-controls', 'dr-block-' + i);
        $(this).find('.collapse').attr('id', 'dr-block-' + i);
        i++;
    });
    $('#sectionSortable').attr('data-last-index', i);
}

function addNewBlock(btn) {
    var type = btn.attr('data-type');
    var src = "";
    var n = $('#sectionSortable .draggable-block').length;
    var index = $('#sectionSortable').attr('data-last-index');
    var id = 'dr-block-' + index;
    switch (type) {
        case 'text':
            src = getBlockTemplate('text', id, 'Text',
                '<textarea class="form-text-area border-0 p-0 mt-4" placeholder="Enter some text..."></textarea>');
            break;
        case 'gallery':
            src = getBlockTemplate('gallery', id, 'Gallery',
                '<div class="gallery-container"><div class="g-uploader">'
                +'<p></p></div></div>');
            break;
        case 'youtube':
            src = getBlockTemplate('youtube', id, 'Youtube Link',
                '<div class="link-beige mt-4"><input type="text" class="youtube-link" placeholder="Enter link to youtube video"/></div>');
            break;
        case 'features':
            src = getBlockTemplate('features', id, 'Features', 
                '<ul class="features-list mt-4"></ul>');
            break;
        case 'quote':
            src = getBlockTemplate('quote', id, 'Quote', '');
            break;
    }

    $('#sectionSortable').attr('data-last-index', Number(index) + 1);
    if (n > 0) {
        $(src).insertAfter($('#sectionSortable .draggable-block').eq(n - 1))
            .on('click', '.cross', function () {
                $(this).closest('.draggable-block').remove();
            });
    } else {
        $('#sectionSortable').append(src)
            .on('click', '.cross', function () {
                $(this).closest('.draggable-block').remove();
            });
    }

    if (type == "text") initRichtextEditor('#dr-block-' + index);
    if (type == "gallery") initPlUploader('#dr-block-' + index);
}

function getBlockTemplate(type, id, header,content) {
    return '<div class="draggable-block bg-grey-2 p-3 mb-2 '+type+'-card-block">'
        + '<div class="draggable-block-header">'
        + '<div class="draggable-marker"></div>'
        + '<h6>'+header+'</h6>'
        + '<div class="cross"></div>'
        + '<div class="collapse-btn collapsed" data-toggle="collapse" href="#' + id + '" role="button" aria-expanded="true" aria-controls="' + id + '"></div>'
        + '</div>'
        + '<div class="collapse show" id="' + id + '">'
        + content
        + '</div>'
        + '</div>'
}

function validateForm() {
    // copy tags to hidden field
    var str = '';
    $('.tags-list .tag-item').each(function () {
        str += $(this).find('div:first-child').text() + ',';
    });
    $('#Tags').val(str);


    $('.richText-editor').each(function () {
       // console.log($(this).html());
    });

    if ($('.toggle-btn').hasClass('checked')
        && Number($('#priceFrom').val()) > Number($('#priceTo').val()))
        return false;

    var startDate = new Date($('#startDate').val()).setHours($('#startTime').val());
    var endDate = new Date($('#endDate').val()).setHours($('#endTime').val());
    console.log(new Date(startDate) + ' - ' + new Date(endDate));
    if (startDate >= endDate) return false;
    return true;
}

$(function () {

    $('form').validate({
        highlight: function (element, errorClass) {
            if ($(element).hasClass('currency-input'))
                $(element).add($(element).parent()).addClass("invalidElem");
            else $(element).add($(element)).addClass("invalidElem");
        },
        unhighlight: function (element, errorClass) {
            if ($(element).hasClass('currency-input'))
                $(element).add($(element).parent()).removeClass("invalidElem");
            else $(element).add($(element)).removeClass("invalidElem");
        },
        errorElement: "div",
        errorClass: "errorMsg"
    });

    $.validator.addClassRules({
        titleValidation: {
            required: true,
            maxlength: 70
        },
        descriptionValidation: {
            required:true
        },
        currencyValidation: {
            number:true
        },
        reqCurrencyValidation: {
            required: true,
            number: true
        },
        dateValidation: {
            dpDate: true
        }
    })

    $('#titleField').addClass("titleValidation").change(function (e) {
        $('form').validate().element($(e.target));
    });

    $('#descriptionField').addClass("descriptionValidation").change(function (e) {
        $('form').validate().element($(e.target));
    });

    $('.currency-input').addClass("currencyValidation").change(function (e) {
        $('form').validate().element($(e.target));
    });

    $('#priceFrom').addClass("reqCurrencyValidation").change(function (e) {
        $('form').validate().element($(e.target));
    });

    $('.datepicker').addClass("dateValidation").change(function (e) {
        $('form').validate().element($(e.target));
    });

});

jQuery.validator.addMethod("dpDate",
    function (value, element, params) {
        var d = new Date(value);
        if (isNaN(d.getTime())) return false;
        var arr = value.split('/');
        if (Number(arr[0]) == 4 || Number(arr[0]) == 6 || Number(arr[0]) == 9 || Number(arr[0]) == 11)
            return (Number(arr[1]) <= 30);
        if (Number(arr[0] == 2))
            if (Number(arr[2]) % 4 == 0) return (Number(arr[1]) <= 29)
            else return (Number(arr[1]) <= 28);
        return true;
    }, 'Enter date in format mm/dd/yyyy');


function initRichtextEditor(selector) {
    console.log(selector);
    var toolbarOptions = [
        [{ 'header': 1 }, { 'header': 2 }],
        ['bold', 'italic', 'underline'],
        [{ 'align': [] }],
        [{ 'list': 'bullet' }],
        ['link']
    ]
    var quill = new Quill(selector, {
        modules: {
            toolbar: toolbarOptions
        },
        theme: 'bubble',
        placeholder: 'Enter some text...',
    });
}

function initPlUploader(selector) {
    $(selector +' .g-uploader').plupload({
        // General settings
        runtimes: 'html5,html4',
        url: "/examples/upload",

        // Maximum file size
        max_file_size: '2mb',

        chunk_size: '1mb',

        // Resize images on clientside if we can
        resize: {
            width: 200,
            height: 200,
            quality: 90,
            crop: true // crop to exact dimensions
        },

        thumb_width: 90,
        thumb_height: 90, 

        // Specify what files to browse for
        filters: [
            { title: "Image files", extensions: "jpg,png" }
        ],

        // Rename files by clicking on their titles
        rename: true,

        // Sort files
        sortable: true,

        // Enable ability to drag'n'drop files onto the widget (currently only HTML5 supports that)
        dragdrop: true,

        // Views to activate
        views: {
            list: false,
            thumbs: true, // Show thumbs
            active: 'thumbs'
        },
        init: {
            PostInit: function () {
                // Called after initialization is finished and internal event handlers bound
                console.log('[PostInit]');

               
            }
        }
    });

    // add new image to gallery when click on empty space
    $(selector).on('click', '.plupload_dropbox', function (event) {
        console.log(selector + "  - " + event.target);
        if ($(event.target).hasClass('plupload_droptext') ||
            $(event.target).hasClass('plupload_dropbox')) {
            $(selector).find('.g-uploader').find('input[type=file]').trigger('click');
        }
        event.stopPropagation();
    });
}

function addTag(str) {
    var tagsCount = $('.tags-list .tag-item').length;
    if (tagsCount >= 10) return;
    var hasThisTag = false;
    $('.tags-list .tag-item .tag-value').each(function () {
        if ($(this).text().toUpperCase() == str.toUpperCase()) {
            hasThisTag = true;
        }
    });
    if (!hasThisTag)
        $('.tags-list').append('<div class="tag-item"><div class="tag-value">' + str + '</div><div class="cross"></div></div>')
                       .on('click', '.cross', function () {
                            $(this).parent().remove();
                       });
}