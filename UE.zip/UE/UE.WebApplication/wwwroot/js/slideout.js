﻿
    //Exelent little functions to use any time when class modification is needed
    function hasClass(ele, cls) {
        return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
    }
    function addClass(ele, cls) {
        if (!hasClass(ele, cls)) ele.className += " " + cls;
    }
    function removeClass(ele, cls) {
        if (hasClass(ele, cls)) {
            var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
            ele.className = ele.className.replace(reg, ' ');
        }
    }
    //Add event from js the keep the marup clean
    function init() {
        document.getElementById("menu-toggle").addEventListener("click", toggleMenu);
        document.getElementById("menu-toggle-2").addEventListener("click", toggleMenuo);
    }
    //The actual fuction
    function toggleMenu() {
        var ele = document.getElementsByTagName('body')[0];
        if (!hasClass(ele, "open")) {
            addClass(ele, "open");

            var heighte = $(window).height();
            $('.page-wrap').height(heighte); 

        } else {
            removeClass(ele, "open");
        }
}


function toggleMenuo() {
    var ele = document.getElementsByTagName('body')[0];
    if (!hasClass(ele, "open")) {
        addClass(ele, "open");
    } else {
        removeClass(ele, "open");
    }
}


    //Prevent the function to run before the document is loaded
    document.addEventListener('readystatechange', function () {
        if (document.readyState === "complete") {
            init();
        }
    });

