﻿$(document).ready(function () {

    $.validator.addMethod("pwcheck", function (value) {
        return /[A-Z]/.test(value) // consists of only these
            && /[a-z]/.test(value) // has a lowercase letter
            && /\d/.test(value) // has a digit
    });

    var validatorStepOne = $('#step-1').validate({
        rules: {
            "Email": {
                required: true,
                email: true
            },
            "Password": {
                required: true,
                minlength: 8,
                pwcheck: true
            },
            "ConfirmPassword": {
                equalTo: '#Password'
            }
        },
        messages: {
            "Email": {
                required: "Email is required",
                email: "Please enter a valid email address"
            },
            "Password": {
                required: "Password is required",
                pwcheck: "Password does not match criteria"
            }
        }
    });

    var validatorStepTwo = $('#step-2').validate({
        rules: {
            "Firstname": {
                required: true
            },
            "Lastname": {
                required: true
            },
            "Phone": {
                required: true
            },
            "Company": {
                required: true
            }
        },
        messages: {
            "Firstname": {
                required: "First name is required"
            },
            "Lastname": {
                required: "Last name is required"
            },
            "Phone": {
                required: "Phone is required"
            },
            "Company": {
                required: "Company is required"
            }
        }
    });

    //Password checkup box
    $('#Password').keyup(function() {
        var pswd = $(this).val();
        if (pswd.length < 8) {
          $('#length').removeClass('valid').addClass('invalid');
        } else {
          $('#length').removeClass('invalid').addClass('valid');
            }

        //validate letter
        if (pswd.match(/[a-z]/)) {
        $('#letter').removeClass('invalid').addClass('valid');
        } else {
        $('#letter').removeClass('valid').addClass('invalid');
        }

        //validate uppercase letter
        if (pswd.match(/[A-Z]/)) {
          $('#capital').removeClass('invalid').addClass('valid');
        } else {
          $('#capital').removeClass('valid').addClass('invalid');
        }

        //validate number
          if (pswd.match(/[0-9]/)) {
          $('#number').removeClass('invalid').addClass('valid');
        } else {
          $('#number').removeClass('valid').addClass('invalid');
        }
      }).focus(function() {
        $('#pswd_info').show();
      }).blur(function() {
        $('#pswd_info').hide();
    });

    $('body').on('click', '.password-control', function () {
        var pwdBox = $(this).parent('div').children('input').first();
        if ($(pwdBox).attr('type') === 'password') {
            $(this).addClass('view');
            $(pwdBox).attr('type', 'text');
        } else {
            $(this).removeClass('view');
            $(pwdBox).attr('type', 'password');
        }
        return false;
    });

    $.fn.inputfocus = function (params) {
        params = $.extend({ focus_class: "focus", value: "" }, params);
        this.each(function () {
            $(this).focus(function () {
                $(this).addClass(params.focus_class);
                this.value = (this.value == params.value) ? '' : this.value;
            });
            $(this).blur(function () {
                $(this).removeClass(params.focus_class);
                this.value = (this.value == '') ? params.value : this.value;
            });
        }); return this;
    };

    $('#agree').on('change', function () {
        if ($(this).is(':checked')) $('.submit').removeClass('chek-checkbox');
        else $('.submit').addClass('chek-checkbox');
    }); 

    $('#submit_first').click(function () {
        var step = $("#first_step");
        var valid = true;
        $('input', step).each(function (i, v) {
            valid = validatorStepOne.element(v) && valid;
        });
        if (valid) {
            $.post('/account/registeremail', $('#step-1').serialize()).done(function (data) {
                if (data.isSuccess) {
                    var inputId = $('<input type="hidden" id="Id" name="Id"></input>');
                    $(inputId).val(data.userId);
                    $('#step-2').prepend(inputId);
                    $('#first_step').slideLeftHide();
                    $('#second_step').slideLeftShow();
                    $('.steps-bar .item-one').removeClass('active').addClass('completed');
                    $('.steps-bar .item-two').addClass('active');
                }
            });
        }
        return false;
    });

    $('#submit_second').click(function () {
        var step = $("#second_step");
        var valid = true;
        $('input', step).each(function (i, v) {
            valid = validatorStepTwo.element(v) && valid;
        });
        if (valid) {
            $.post('/account/registerdetails', $('#step-2').serialize()).done(function (data) {
                window.location = "/account/RegisterSuccess";
            });
        } 
        return false;
    });
});

$.fn.extend({
    slideLeftHide: function () {
        return this.each(function () {
            $(this).hide('slide', { direction: 'left' }, 400);
        });
    },
    slideLeftShow: function () {
        return this.each(function () {
            $(this).show('slide', { direction: 'left' }, 400);
        });
    }
});
