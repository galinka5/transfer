using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using UE.WebApplication.Extensions;

namespace UE.WebApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                var configuration = new ConfigurationBuilder()
                .ComposeConfigFiles(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"))
                .Build();
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Startup error message {ex.Message}");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                    webBuilder.ConfigureAppConfiguration((buildContext, config) => 
                    {
                        config.ComposeConfigFiles(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"));
                    });
                });
    }
}
