using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using UE.Db.Seed;
using UE.WebApplication.Extensions;

namespace UE.WebApplication
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<HtmlHelperOptions>(o => o.ClientValidationEnabled = false);

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });
            services.AddResponseCompression();
            services.InstallServices(Configuration);
            services.AddControllersWithViews();
            services.InstallAuthentication(Configuration);
            services.AddRouting(options => 
            {
                options.LowercaseUrls = true;
            });
            services.ConfigureApplicationCookie(options =>
            {
                options.AccessDeniedPath = "/account/access-denied";
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ApplicationSeeder seeder)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseErrorLogging();
            
            app.UseResponseCompression();
            
            app.UseHttpsRedirection();
            
            app.UseStaticFiles();

            app.UpdateDatabase(seeder);

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
